package com.bigdataleap.samples.hbase;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.client.Delete;
import org.apache.hadoop.hbase.client.Get;
import org.apache.hadoop.hbase.client.HConnection;
import org.apache.hadoop.hbase.client.HConnectionManager;
import org.apache.hadoop.hbase.client.HTableInterface;
import org.apache.hadoop.hbase.client.Put;
import org.apache.hadoop.hbase.client.Result;
import org.apache.hadoop.hbase.client.ResultScanner;
import org.apache.hadoop.hbase.client.Scan;
import org.apache.hadoop.hbase.filter.BinaryComparator;
import org.apache.hadoop.hbase.filter.CompareFilter.CompareOp;
import org.apache.hadoop.hbase.filter.Filter;
import org.apache.hadoop.hbase.filter.FilterList;
import org.apache.hadoop.hbase.filter.RegexStringComparator;
import org.apache.hadoop.hbase.filter.SingleColumnValueFilter;
import org.apache.hadoop.hbase.util.Bytes;

public class CustUtility {

	HConnection connection = null;
	HTableInterface hbaseTable = null;

	// Reading records from the table based on row-key
	public void getCustomerInfo(String id) throws IOException {
		Get g = new Get(Bytes.toBytes(id));
		Result r = hbaseTable.get(g);

		g.addFamily("personalinfo".getBytes());

		System.out.println(" Firstname : "
				+ getColumnValue(r, "personalinfo", "firstname"));
		System.out.println(" Lastname : "
				+ getColumnValue(r, "personalinfo", "lastname"));
		System.out
				.println(" Age : " + getColumnValue(r, "personalinfo", "age"));
		System.out.println(" Profession : "
				+ getColumnValue(r, "personalinfo", "profession"));

	}

	private String getColumnValue(Result r, String family, String qual) {

		byte[] val = r.getValue(Bytes.toBytes(family), Bytes.toBytes(qual));

		if (val != null)
			return new String(val);
		else
			return "";
	}

	// Reading all records from the table
	public void scanFullTable() throws IOException {
		Scan s = new Scan();
		ResultScanner rs = hbaseTable.getScanner(s);

		for (Result r : rs) {
			System.out.println(" Custid: " + new String(r.getRow()));
			System.out.println(" Firstname : "
					+ getColumnValue(r, "personalinfo", "firstname"));
			System.out.println(" Lastname : "
					+ getColumnValue(r, "personalinfo", "lastname"));
			System.out.println(" Age : "
					+ getColumnValue(r, "personalinfo", "age"));
			System.out.println(" Profession : "
					+ getColumnValue(r, "personalinfo", "profession"));
		}
	}

	// Reading records from the table from a beginning key to end key (Range of
	// records)
	public void scanTableRange(String startid, String endid) throws IOException {
		Scan s = new Scan(startid.getBytes(), endid.getBytes());
		ResultScanner rs = hbaseTable.getScanner(s);

		for (Result r : rs) {
			System.out.println(" Custid: " + new String(r.getRow()));
			System.out.println(" Firstname : "
					+ getColumnValue(r, "personalinfo", "firstname"));
			System.out.println(" Lastname : "
					+ getColumnValue(r, "personalinfo", "lastname"));
			System.out.println(" Age : "
					+ getColumnValue(r, "personalinfo", "age"));
			System.out.println(" Profession : "
					+ getColumnValue(r, "personalinfo", "profession"));

		}
	}

	// Using value filter - get all customer records that have more than a
	// certain age
	public void filterByAge(String age) throws IOException {
		SingleColumnValueFilter filter = new SingleColumnValueFilter(
				Bytes.toBytes("personalinfo"), Bytes.toBytes("age"),
				CompareOp.GREATER_OR_EQUAL, new BinaryComparator(
						Bytes.toBytes(age)));

		Scan s = new Scan();
		s.setFilter(filter);
		ResultScanner rs = hbaseTable.getScanner(s);

		for (Result r : rs) {
			System.out.println(" Custid: " + new String(r.getRow()));
			System.out.println(" Firstname : "
					+ getColumnValue(r, "personalinfo", "firstname"));
			System.out.println(" Lastname : "
					+ getColumnValue(r, "personalinfo", "lastname"));
			System.out.println(" Age : "
					+ getColumnValue(r, "personalinfo", "age"));
			System.out.println(" Profession : "
					+ getColumnValue(r, "personalinfo", "profession"));
		}

		rs.close();
	}

	// Using Multiple filters - get all customer records that have specific
	// profession and age
	public void filterByAgeAndProfession(String age, String profession)
			throws IOException {
		List<Filter> filters = new ArrayList<Filter>(2);

		SingleColumnValueFilter filter1 = new SingleColumnValueFilter(
				Bytes.toBytes("personalinfo"), Bytes.toBytes("age"),
				CompareOp.GREATER_OR_EQUAL, new BinaryComparator(
						Bytes.toBytes(age)));

		SingleColumnValueFilter filter2 = new SingleColumnValueFilter(
				Bytes.toBytes("personalinfo"), Bytes.toBytes("profession"),
				CompareOp.EQUAL, new RegexStringComparator(profession));

		filters.add(filter1);
		filters.add(filter2);

		FilterList filterList = new FilterList(
				FilterList.Operator.MUST_PASS_ALL, filters);

		Scan s = new Scan();
		s.setFilter(filterList);
		ResultScanner rs = hbaseTable.getScanner(s);

		// filter.setLatestVersionOnly( false ); // All versions of the rows....

		for (Result r : rs) {
			System.out.println(" Custid: " + new String(r.getRow()));
			System.out.println(" Firstname : "
					+ getColumnValue(r, "personalinfo", "firstname"));
			System.out.println(" Lastname : "
					+ getColumnValue(r, "personalinfo", "lastname"));
			System.out.println(" Age : "
					+ getColumnValue(r, "personalinfo", "age"));
			System.out.println(" Profession : "
					+ getColumnValue(r, "personalinfo", "profession"));
		}

		rs.close();
	}

	// Update a record
	public void updateAge(String id, String age) throws IOException {
		Put put = new Put(id.getBytes());
		put.add("personalinfo".getBytes(), "age".getBytes(), age.getBytes());

		hbaseTable.put(put);
	}

	// delete a record
	public void deleteCustomer(String id) throws IOException {
		Delete delete = new Delete(id.getBytes());

		hbaseTable.delete(delete);
	}

	// delete a column qualifier in a record
	public void deleteAge(String id) throws IOException {
		Delete delete = new Delete(id.getBytes());

		delete.deleteColumn("personalinfo".getBytes(), "age".getBytes());

		delete.deleteFamily("personalinfo".getBytes());

		hbaseTable.delete(delete);
	}

	// initilize the connection to the hbase table -
	// replace the ip address of hmaster and zookeeper
	private void initTable() throws IOException {
		Configuration conf = HBaseConfiguration.create();
		conf.set("hbase.master", "192.168.19.129:60010");
		conf.set("hbase.zookeeper.quorum", "192.168.19.129");

		connection = HConnectionManager.createConnection(conf);
		hbaseTable = connection.getTable("custs");
	}

	// close connection at the end
	private void closeConnection() throws IOException {
		if (connection != null)
			connection.close();
	}

	public static void main(String args[]) throws IOException {

		CustUtility loader = new CustUtility();

		// Initialize the connection to the hbase table
		loader.initTable();

		System.out
				.println("******************************************************************************");
		System.out.println(" Reading a customer record with custid = 4000010 ");

		// ***************** Read a customer record **********************
		loader.getCustomerInfo("001");

		System.out
				.println("******************************************************************************");
		System.out
				.println(" \n\n\nUpdating customer age to 45 for custid = 4000010 ");
		CustUtility.readConsole();

		// ***************** update a customer record **********************
		loader.updateAge("4000010", "25");
		loader.getCustomerInfo("4000010");

		// count number of versions for the record from hbase shell > get
		// 'custs', '4000010', VERSIONS => 2

		System.out
				.println("******************************************************************************");
		System.out.println(" \n\n\nDeleting customer with custid = 4000010 ");
		CustUtility.readConsole();

		// ***************** Deleting a cutomer record **********************
		loader.deleteCustomer("4000012");

		// check if record is deleted from hbase shell > get 'custs', '4000011'

		System.out
				.println("******************************************************************************");
		System.out
				.println(" \n\n\nScanning customer records ranging from 4000100 to 4000120");
		CustUtility.readConsole();

		// ***************** Scan the full table **********************
		// loader.scanFullTable();

		// ***************** Scan a table range **********************
		loader.scanTableRange("4000100", "4000120");

		System.out
				.println("******************************************************************************");
		System.out.println(" \n\n\nFiltering customers with age more than 45 ");
		CustUtility.readConsole();

		// ***************** Search by a predicate **********************
		loader.filterByAge("45");

		System.out
				.println("******************************************************************************");
		System.out
				.println(" \n\n\nFiltering customers with age more than 60 and actor ");
		CustUtility.readConsole();

		// ***************** Search by a predicate with multiple filters
		// **********************
		loader.filterByAgeAndProfession("60", "Act" + "[\\S]+");

		loader.closeConnection();
	}

	public static void readConsole() throws IOException {
		System.out.println("Press enter to proceed.");
		BufferedReader inreader = new BufferedReader(new InputStreamReader(
				System.in));
		inreader.readLine();
	}

}
