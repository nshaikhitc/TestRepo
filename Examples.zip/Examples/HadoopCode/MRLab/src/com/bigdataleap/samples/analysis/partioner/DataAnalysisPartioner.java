package com.bigdataleap.samples.analysis.partioner;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Partitioner;

public class DataAnalysisPartioner extends Partitioner<Text, DoubleWritable> {

	@Override
	public int getPartition(Text arg0, DoubleWritable arg1, int arg2) {
		Double val = new Double(arg1.toString());
		if (val >= 0.0 && val <= 20.0) {
			return 0;
		} else if (val > 20.0 && val <= 50.0) {
			return 1;
		} else {
			return 2;
		}

	}
}
