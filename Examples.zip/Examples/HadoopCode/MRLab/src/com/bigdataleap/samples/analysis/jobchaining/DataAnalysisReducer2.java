package com.bigdataleap.samples.analysis.jobchaining;

import java.io.IOException;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class DataAnalysisReducer2 extends Reducer<Text, Text, Text, Text> {
	public void reduce(Text key, Iterable<Text> values, Context context)
			throws IOException, InterruptedException {

		double sum = 0.0;
		String temp = "";
		for (Text val : values) {
			String line = val.toString();
			String[] tokens = line.split("\t");
			Double amount = new Double(tokens[1]);
			if (amount > sum) {
				sum = amount;
				temp = line;
			} else if (amount == sum) {
				sum = amount;
				temp = temp + "\t" + line;
			}
		}

		context.write(key, new Text(temp));
	}
}