package com.bigdataleap.samples.analysis.counter;

import java.io.IOException;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class DataAnalysisMapper extends
		Mapper<LongWritable, Text, Text, DoubleWritable> {

	enum RETAIL_TXN_RECORDS {
		TOTAL_TXNS, TOTAL_CREDIT_TXNS, TOTAL_CASH_TXNS
	}

	public void map(LongWritable key, Text value, Context context)
			throws IOException, InterruptedException {

		String line = value.toString();

		String[] tokens = line.split(",");

		context.getCounter(RETAIL_TXN_RECORDS.TOTAL_TXNS).increment(1);
		if (tokens[8].equalsIgnoreCase("credit")) {
			context.getCounter(RETAIL_TXN_RECORDS.TOTAL_CREDIT_TXNS).increment(
					1);
		}
		if (tokens[8].equalsIgnoreCase("cash")) {
			context.getCounter(RETAIL_TXN_RECORDS.TOTAL_CASH_TXNS).increment(1);
		}
		context.write(new Text(tokens[5].trim() + "	" + tokens[7].trim()),
				new DoubleWritable(new Double(tokens[3].trim())));

	}
}
