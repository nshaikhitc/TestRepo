package com.bigdataleap.samples.analysis.reduceJoin;

import java.io.IOException;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class JoiningTxnsMapper extends Mapper<LongWritable, Text, Text, Text> {

	public void map(LongWritable key, Text value, Context context)
			throws IOException, InterruptedException {

		String line = value.toString();

		String[] tokens = line.split(",");

		context.write(new Text(tokens[2]),
				new Text(tokens[0].trim() + "-" + tokens[1].trim() + "-"
						+ tokens[3].trim() + "-" + tokens[4].trim() + "-"
						+ tokens[5].trim() + "-" + tokens[6].trim() + "-"
						+ tokens[7].trim() + "-" + tokens[8].trim()));

	}
}