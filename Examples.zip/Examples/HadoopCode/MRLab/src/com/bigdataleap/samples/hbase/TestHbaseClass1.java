package com.bigdataleap.samples.hbase;

import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.client.Get;
import org.apache.hadoop.hbase.client.HConnection;
import org.apache.hadoop.hbase.client.HConnectionManager;
import org.apache.hadoop.hbase.client.HTableInterface;
import org.apache.hadoop.hbase.client.Result;

public class TestHbaseClass1 {

	public static void main(String args[]) {
		Configuration conf = HBaseConfiguration.create();
		conf.set("hbase.master", "192.168.19.129:60010");
		conf.set("hbase.zookeeper.quorum", "192.168.19.129");

		try {
			HConnection connection = HConnectionManager.createConnection(conf);
			HTableInterface hbaseTable = connection.getTable("custs");

			Get g = new Get("001".getBytes());
			Result r = hbaseTable.get(g);
			g.addFamily("personalinfo".getBytes());

			System.out.println("Name: "
					+ getColumnValue(r, "personalinfo", "name"));
			System.out.println("Age : "
					+ getColumnValue(r, "personalinfo", "age"));

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public static String getColumnValue(Result r, String family, String qual) {
		byte[] val = r.getValue(family.getBytes(), qual.getBytes());

		if (null != val) {
			return new String(val);
		} else {
			return "";
		}
	}
}
