package com.bigdataleap.samples.analysis.reduceJoin;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.MultipleInputs;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.util.GenericOptionsParser;

public class JoiningDriver {

	public static void main(String[] args) {
		Configuration conf = new Configuration();

		String[] otherArgs;
		try {
			otherArgs = new GenericOptionsParser(conf, args).getRemainingArgs();

			Job job = Job.getInstance(conf);
			job.setJobName("Map Side Join");
			job.setJarByClass(JoiningDriver.class);
			job.setMapperClass(JoiningTxnsMapper.class);
			job.setMapperClass(JoiningCustsMapper.class);
			job.setReducerClass(JoiningReducer.class);
			job.setMapOutputKeyClass(Text.class);
			job.setMapOutputValueClass(Text.class);
			MultipleInputs.addInputPath(job, new Path(otherArgs[0]),
					TextInputFormat.class, JoiningTxnsMapper.class);
			MultipleInputs.addInputPath(job, new Path(otherArgs[1]),
					TextInputFormat.class, JoiningCustsMapper.class);
			FileOutputFormat.setOutputPath(job, new Path(otherArgs[2]));
			job.waitForCompletion(true);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
