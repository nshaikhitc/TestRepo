package com.bigdataleap.samples.analysis.jobchaining;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapred.jobcontrol.JobControl;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.jobcontrol.ControlledJob;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.util.GenericOptionsParser;

public class DataAnalysisDriver {

	public static void main(String[] args) throws Exception {

		Configuration conf = new Configuration();

		String[] otherArgs = new GenericOptionsParser(conf, args)
				.getRemainingArgs();
		ControlledJob cJob1 = new ControlledJob(conf);
		cJob1.setJobName("Retail Data Analysis Job 1 and 2");
		Job job = cJob1.getJob();
		job.setJarByClass(DataAnalysisDriver.class);
		job.setMapperClass(DataAnalysisMapper.class);
		job.setReducerClass(DataAnalysisReducer.class);

		job.setMapOutputKeyClass(Text.class);
		job.setMapOutputValueClass(DoubleWritable.class);

		job.setOutputKeyClass(Text.class);
		job.setOutputValueClass(DoubleWritable.class);

		FileInputFormat.addInputPath(job, new Path(otherArgs[0]));
		FileOutputFormat.setOutputPath(job, new Path(otherArgs[1]));

		Configuration conf2 = new Configuration();

		String[] otherArgs1 = new GenericOptionsParser(conf2, args)
				.getRemainingArgs();
		ControlledJob cJob2 = new ControlledJob(conf2);
		cJob2.setJobName("Retail Data Analysis Job 1 and 2");
		Job job1 = cJob2.getJob();
		job1.setJarByClass(DataAnalysisDriver.class);
		job1.setMapperClass(DataAnalysisMapper2.class);
		job1.setReducerClass(DataAnalysisReducer2.class);

		job1.setMapOutputKeyClass(Text.class);
		job1.setMapOutputValueClass(Text.class);

		job1.setOutputKeyClass(Text.class);
		job1.setOutputValueClass(Text.class);

		FileInputFormat.addInputPath(job1, new Path(otherArgs1[1]));
		FileOutputFormat.setOutputPath(job1, new Path(otherArgs1[2]));

		cJob2.addDependingJob(cJob1);
		JobControl control = new JobControl("Analysyis");
		control.addJob(cJob1);
		control.addJob(cJob2);
		control.run();

	}

}
