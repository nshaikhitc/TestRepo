package com.bigdataleap.samples.analysis.mapjoin;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URI;
import java.util.HashMap;

import org.apache.hadoop.fs.FSDataInputStream;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

import au.com.bytecode.opencsv.CSVReader;

public class JoiningMapper extends
		Mapper<LongWritable, Text, Text, NullWritable> {
	private HashMap customers = new HashMap();

	@Override
	public void setup(Context context) throws IOException {
		URI[] uri = context.getCacheFiles();
		if (uri.length == 0) {
			throw new FileNotFoundException("Distributed cache file not found.");
		}
		FileSystem fs = FileSystem.get(context.getConfiguration());
		FSDataInputStream in = fs.open(new Path(uri[0]));
		BufferedReader br = new BufferedReader(new InputStreamReader(in));
		readCacheFile(br);
	}

	private void readCacheFile(BufferedReader breader) throws IOException {
		CSVReader reader = null;
		reader = new CSVReader(breader);
		String[] nextLine;
		while ((nextLine = reader.readNext()) != null) {
			customers.put(nextLine[0], nextLine[1] + "," + nextLine[2] + ","
					+ nextLine[3]);
		}
		if (reader != null)
			reader.close();
	}

	@Override
	public void map(LongWritable key, Text value, Context context)
			throws IOException, InterruptedException {
		String txnString = value.toString();
		String[] txnData = txnString.split(",");
		String customerRec = (String) customers.get(txnData[2]);
		context.write(new Text(value + "," + customerRec), NullWritable.get());
	}
}