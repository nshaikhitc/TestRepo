package com.bigdataleap.samples.analysis.reduceJoin;

import java.io.IOException;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class JoiningReducer extends Reducer<Text, Text, Text, Text> {
	public void reduce(Text key, Iterable<Text> values, Context context)
			throws IOException, InterruptedException {

		Text line = null;
		if (null != values) {

			for (Text value : values) {
				if (null != line) {
					line = new Text(value + "-" + line);
				} else {
					line = value;
				}
			}
			line = new Text(line + "\n");
		}
		context.write(key, line);
	}
}