package com.bigdataleap.samples.analysis.jobchaining;

import java.io.IOException;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class DataAnalysisMapper extends
		Mapper<LongWritable, Text, Text, DoubleWritable> {

	public void map(LongWritable key, Text value, Context context)
			throws IOException, InterruptedException {

		String line = value.toString();

		String[] tokens = line.split(",");

		context.write(new Text(tokens[5].trim() + "	" + tokens[7].trim()),
				new DoubleWritable(new Double(tokens[3].trim())));

	}
}
